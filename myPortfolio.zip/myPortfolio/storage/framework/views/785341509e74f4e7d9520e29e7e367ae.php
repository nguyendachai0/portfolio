<!-- Add your site or app content here -->
<div class="hero-full-container background-image-container white-text-container" style="background-image: url('./assets/images/space.jpg')">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="hero-full-wrapper">
            <div class="text-content">
              <h1><br>
                <span id="typed-strings">
                  <span>Hello,<br> I'm Nguyen Dac Hai</span>
                  <span>Full Stack Web Developer</span>
                  <span></span>
                </span>
                <span id="typed"></span>
              </h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\Users\nguye\Documents\FPTPOLY\WEB2014-Lap_trinh_PHP_1\portfolio\myPortfolio\resources\views/layouts/main.blade.php ENDPATH**/ ?>