

<?php $__env->startSection('content'); ?>
  <!-- Add your site or app content here -->
<div class="hero-full-container background-image-container white-text-container">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="hero-full-wrapper">
            <div class="text-content">
              <h1 class="suckable"><br>
                <span id="typed-strings">
                  <span>Hello,<br> I'm Nguyen Dac Hai</span>
                  <span>Full Stack Web Developer</span>
                  <span></span>
                </span>
                <span id="typed"></span>
              </h1>
              
             
              <form class="form-cv suckable" action="<?php echo e(route('download')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" name="download" onclick="showBlackhole()">Download CV</button>
            </form>

        
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="blackhole hide">
    <div class="merga">
      <div class="black"></div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nguye\Documents\FPTPOLY\WEB2014-Lap_trinh_PHP_1\portfolio\myPortfolio\resources\views/layouts/home.blade.php ENDPATH**/ ?>