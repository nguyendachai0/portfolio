

<?php $__env->startSection('content'); ?>
<div class="section-container">
    <div class="container">
      <div class="row">
        
        <div class="col-sm-8 col-sm-offset-2 section-container-spacer">
          <div class="text-center">
            <h1 class="h2">02 : Works</h1>
            <p>Below are my hightlights project</p>
          </div>
        </div>
  
        <div class="col-md-12">
       
        <div id="myCarousel" class="carousel slide projects-carousel">
          <!-- Carousel items -->
          <div class="carousel-inner">
            <?php $__currentLoopData = $groupedWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twoWorks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item">
                  <div class="row">
                    <?php $__currentLoopData = $twoWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-sm-6">
  
                        <a href="<?php echo e($work->link_deploy); ?>" title="" class="black-image-project-hover">
                          <?php if($work->hover_image_url != ''): ?>
                          <img src="./assets/images/<?php echo e($work->hover_image_url); ?>" alt="" class="img-responsive">
                         <?php else: ?> 
                         <img src="./assets/images/work-default.jpg" alt="" class="img-responsive">
                         <?php endif; ?>
                        </a>
                        <div class="card-container card-container-lg">
                          <h4><?php echo e($work->id); ?>/<?php echo e($worksCount); ?></h4>
                          <h3><?php echo e($work->name); ?></h3>
                          <p><?php echo e($work->description); ?></p>
                          <a href="<?php echo e($work->link_github); ?>" title="" class="btn btn-default">Discover</a>
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                    </div>
                    <!--/row-->
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!--/item-->
              
              
              <!--/item-->
          </div>
          <!--/carousel-inner--> 
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">‹</a>
  
          <a class="right carousel-control" href="#myCarousel" data-slide="next">›</a>
       </div>
  
  
  
      <!--/myCarousel-->
      </div>
  
  
  
      </div>
    </div>
  </div>
  
  
  <footer class="footer-container text-center">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <p>© UNTITLED | Website created with <a href="http://www.mashup-template.com/" title="Create website with free html template">Mashup Template</a>/<a href="https://www.unsplash.com/" title="Beautiful Free Images">Unsplash</a></p>
        </div>
      </div>
    </div>
  </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nguye\Documents\FPTPOLY\WEB2014-Lap_trinh_PHP_1\portfolio\myPortfolio\resources\views/layouts/works.blade.php ENDPATH**/ ?>