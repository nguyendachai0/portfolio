<!-- resources/views/layouts/about.blade.php -->



<?php $__env->startSection('content'); ?>
    <section>
        <h2>About Us</h2>
        <p>This is the about page content.</p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nguye\Documents\FPTPOLY\WEB2014-Lap_trinh_PHP_1\portfolio\myPortfolio\resources\views/about.blade.php ENDPATH**/ ?>